# -*- coding: utf-8 -*-
"""
constants.py —— 全局常量：窗口、棋盘、颜色、帧率
"""

# ---- 窗口 ----
WINDOW_WIDTH = 1280
WINDOW_HEIGHT = 720

# ---- 棋盘 ----
MAX_CELL = 80           # 每格最大边长（像素）
BOARD_TOP = 150         # 棋盘区域顶部留白
BOARD_MARGIN = 20       # 棋盘四周留白

# ---- 颜色 ----
BG_COLOR = (245, 247, 250)
CELL_COLOR = (255, 255, 255)
GRID_LINE = (205, 210, 220)
ARROW_COLOR = (45, 120, 235)
ARROW_BLOCKED = (230, 60, 60)
TEXT_COLOR = (40, 45, 55)
TITLE_COLOR = (30, 60, 120)
HEART_COLOR = (235, 70, 100)
HEART_OFF = (200, 203, 210)

FPS = 60